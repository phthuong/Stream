package ocean.plants;

public class Seaweed {

}
